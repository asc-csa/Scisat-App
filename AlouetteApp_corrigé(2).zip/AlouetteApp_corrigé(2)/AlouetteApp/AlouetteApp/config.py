class Config:
    LANGUAGES = {'en': 'English', 'fr': 'French'}